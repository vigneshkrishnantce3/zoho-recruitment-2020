#include<stdio.h>

void main()
{

char str[100];
scanf("%s",&str);

printf("%s",str);

int length=0;
while(str[length]!='\0') // GET Length
{
    length++;

}
printf("%d",length);
printf("\n");
if(length%2 != 0)
{
    int i,j,n,m;
    for (i=0;i<length;i++)
    {
        n=(length/2);
        m=(n+i);
        for(j=n;j<=m;j++)
        {
            if(j>(length-1))
            {
               j=0;
               m=i-n-1;
            }


            printf("%c",str[j]);
        }
        printf("\n");
    }

}

}
